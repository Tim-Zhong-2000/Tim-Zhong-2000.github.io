win10lite（1809） 恢复powershell方法
1. 解压WindowsPowerShell.zip
2. 将v1.0文件夹覆盖C:\Windows\System32\WindowsPowerShell\v1.0
3. 双击导入powershell注册表
完成！